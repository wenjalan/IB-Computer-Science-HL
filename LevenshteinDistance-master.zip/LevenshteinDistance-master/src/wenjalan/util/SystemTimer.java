package wenjalan.util;

import java.util.ArrayList;

// a timer used to time the execution duration of programs
// uses nanoseconds in calculations
public class SystemTimer {

    // the number of nanoseconds in a second
    private static final double NANOSECONDS_IN_A_SECOND = 1_000_000_000.0D;

    // the last lap time of this program
    private long lastLapTime;

    // the history of lap times
    private ArrayList<Long> lapDurationHistory;

    // constructor
    public SystemTimer() {
        lapDurationHistory = new ArrayList<>();
    }

    // returns the current time in ns
    public long getTime() {
        return System.nanoTime();
    }

    // starts the timer
    public void start() {
        this.lastLapTime = getTime();
    }

    // laps the timer
    // returns the time between this lap and the last lap in seconds
    public double lap() {
        long now = getTime();
        long lastLapDuration = now - this.lastLapTime;
        this.lapDurationHistory.add(lastLapDuration);
        this.lastLapTime = now;
        return getLastLapDuration();
    }

    // returns the last lap duration in seconds
    public double getLastLapDuration() {
        long lastLapDuration = this.lapDurationHistory.get(lapDurationHistory.size() - 1);
        return lastLapDuration / NANOSECONDS_IN_A_SECOND;
    }

}
