package wenjalan;

import wenjalan.util.SystemTimer;

import java.io.*;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

    // SystemTimer for timing
    SystemTimer timer = new SystemTimer();

    // TreeSet that stores the Dictionary
    TreeSet<String> dictionary;

    // main
    public static void main(String[] args) {
        File dictionaryFile = new File("dictionary words.txt");
        new Main(dictionaryFile);
    }

    // constructor
    public Main(File dictionaryFile) {
        init(dictionaryFile);
        start();
    }

    // initialization
    private void init(File dictionaryFile) {
        // initialize TreeSet to store words
        dictionary = new TreeSet<>();

        // read in the dictionary
        readDictionary(dictionaryFile);
    }

    // reads in the dictionary
    private void readDictionary(File dictionaryFile) {
        try {
            // create a new buffered reader to read the dictionary file
            BufferedReader br = new BufferedReader(new FileReader(dictionaryFile));

            // read in the words
            String word;
            while ((word = br.readLine()) != null) {
                // add the word to the dictionary
                dictionary.add(word);
            }

            // close
            br.close();
        } catch (Exception e) {
            // print error info
            System.err.println("Failed to load dictionary!");
            e.printStackTrace();
            System.exit(1);
        }
    }

    // start the program
    private void start() {
        // Console Scanner
        Scanner console = new Scanner(System.in);

        // keep running the program
        while (true) {
            // ask for two words
            System.out.print("Enter two words to calculate Levenshtein distance: ");
            String word1 = console.next().toLowerCase();
            // check if we should quit
            if (word1.equalsIgnoreCase("quit")) {
                System.out.println("Quitting...");
                break;
            }

            String word2 = console.next().toLowerCase();


            // if either word isn't in the dictionary
            if (!dictionary.contains(word1)) {
                // complain
                System.out.println(word1 + " isn't a word!");
                console.nextLine();
                continue;
            }
            else if (!dictionary.contains(word2)) {
                // complain
                System.out.println(word1 + " isn't a word!");
                console.nextLine();
                continue;
            }

            // calculate the distance between the two words
            int distance = getLevenshteinDistance(word1, word2);

            // print it out
            System.out.println("Levenshtein distance: " + distance);
        }

    }

    // calculates the Levenshtein distance between two words
    private int getLevenshteinDistance(String sourceWord, String targetWord) {
        // if the source word matches the target word
        if (sourceWord.equalsIgnoreCase(targetWord)) {
            return 0;
        }

        // for each character in the targetWord
        for (int i = 0; i < targetWord.length(); i++) {
            // get the characters of the source word
            char[] testWord = sourceWord.toCharArray();

            // skip this character if it already matches the target word
            if (testWord[i] == targetWord.charAt(i)) {
                continue;
            }

            // create a test word that has one character from the target word swapped in
            testWord[i] = targetWord.charAt(i);
            String newWord = String.valueOf(testWord);

            // test if it's a valid word
            if (dictionary.contains(newWord)) {
                // print it
                System.out.println(newWord);
                return 1 + getLevenshteinDistance(newWord, targetWord);
            }
        }

        // if no valid new word was found, return -1
        return -1;
    }
}
