package wenjalan.questlogapp.animation;
// master Animation class holds animation parameters

import android.view.animation.Animation;

public class QuestLogAnimation {

    // standard time of an animation
    public static long DURATION_LONG = 1000;
    public static long DURATION_SHORT = 100;

}
