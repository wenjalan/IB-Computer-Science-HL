package wenjalan.questlogapp;

/**
 * Created by Alan on 2/18/2018.
 */

public interface Completable {

    public boolean isComplete();

}
