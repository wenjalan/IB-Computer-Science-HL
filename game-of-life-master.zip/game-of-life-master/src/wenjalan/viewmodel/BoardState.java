package wenjalan.viewmodel;

import wenjalan.data.Tile;

// lightweight class used for rendering the board, holds a boolean[][] representing which Tiles are alive
public class BoardState {

    // the boardState
    private boolean[][] boardState;

    // constructor
    public BoardState(Tile[][] board) {
        // fill the boardState
        boardState = new boolean[board.length][board[0].length];
        for (int i = 0; i < boardState.length; i++) {
            for (int j = 0; j < boardState[i].length; j++) {
                boardState[i][j] = board[i][j].isAlive();
            }
        }
    }

    public BoardState(boolean[][] state) {
        boardState = state;
    }

    // returns the boardState
    public boolean[][] getState() {
        return this.boardState;
    }

}
