package wenjalan.viewmodel;

import wenjalan.data.Board;
import wenjalan.view.LifeMouseListener;
import wenjalan.view.Window;

// Represents the Game of Life; contains main()
public class Life {

    // Target FPS
    public static final double TARGET_FPS = 60;

    // Board dimensions
    public static final int BOARD_WIDTH = 100;
    public static final int BOARD_HEIGHT = 50;

    // the instance of Board
    private Board board;

    // the instance of Window
    private Window window;

    // if game should run
    private boolean running;

    // if the game is paused
    private static boolean paused;

    // main
    public static void main(String[] args) {
        new Life();
    }

    // constructor
    private Life() {
        init();
        start();
        exit();
    }

    // initialization
    private void init() {
        // initialize Board
        this.board = Board.getInstance();
        // initialize Window
        this.window = new Window();
        // set run state
        this.running = true;
        // set paused state
        this.paused = false;
    }

    // start; game loop
    private void start() {
        // record timing variables
        double lastUpdateTimeStamp = System.currentTimeMillis(); // time stamp of the previous update
        double currentTime; // the time it is right now
        double lastUpdateToCurrentDelta; // the time passed between the last update and right now

        // while the game is running
        while (running) {
            // get the current time
            currentTime = System.currentTimeMillis();

            // calculate the time passed between the last update and now
            lastUpdateToCurrentDelta = currentTime - lastUpdateTimeStamp;

            // if enough time has passed in ms to render a new frame
            if (lastUpdateToCurrentDelta >= 1000 / TARGET_FPS) {
                // if the game isn't paused, update the game state
                // TODO: Render the last loaded BoardState if paused
                // BoardState state = new BoardState(new boolean[BOARD_WIDTH][BOARD_HEIGHT]);
                BoardState state = board.update();

                // do input
                // input();

                // render
                window.update(state);

                // print the update delta
                double fps = 1000.0d / lastUpdateToCurrentDelta;

                // set the lastUpdateTimeStamp to the currentTime
                lastUpdateTimeStamp = currentTime;
                // pass into window
                window.setFPS(fps);
            }
        }
    }

    // toggles whether the game is paused
    public static void togglePause() {
        paused = !paused;
        System.out.println(paused ? "PAUSED GAME" : "UNPAUSED GAME");
    }

    // returns whether the game is paused
    public static boolean isPaused() {
        return paused;
    }

    // exit
    private void exit() {

    }

}
