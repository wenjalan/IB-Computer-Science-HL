package wenjalan.view;

import wenjalan.data.Board;
import wenjalan.viewmodel.BoardState;
import wenjalan.viewmodel.Life;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static wenjalan.viewmodel.Life.BOARD_HEIGHT;
import static wenjalan.viewmodel.Life.BOARD_WIDTH;

// holds the JPanel
public class Window implements ActionListener {

    public static final int FRAME_BOARD_MARGIN = 10;
    public static final int TILE_SPACING = 0;
    public static final int TILE_SIZE = 10;

    // calculate the dimensions of the border
    private final int BORDER_HEIGHT = (BOARD_HEIGHT * (TILE_SIZE + TILE_SPACING)) + FRAME_BOARD_MARGIN * 2;
    private final int BORDER_WIDTH = (BOARD_WIDTH * (TILE_SIZE + TILE_SPACING)) + FRAME_BOARD_MARGIN * 2;

    // Window dimensions
    private final int WIDTH = BORDER_WIDTH + 20;
    private final int HEIGHT = BORDER_HEIGHT + 50;


    private final Dimension WINDOW_SIZE = new Dimension(WIDTH, HEIGHT);

    // Swing components
    private JFrame frame;

    // Custom JPanel
    private Panel panel;

    // FPS value
    private double fps = 0.0;
    private JLabel fpsLabel;

    // RGB generator
    private RGBGenerator rgb;

    // Custom JPanel
    private class Panel extends JPanel {

        // constructor
        Panel() {
            setPreferredSize(WINDOW_SIZE);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            render(g);
//            input();
        }

    }

    // most recent BoardState
    private BoardState state;

    // constructor
    public Window() {
        init();
    }

    // initializes the window
    private void init() {
        // initialize RGB
        rgb = new RGBGenerator();

        // initialize JFrame
        frame = new JFrame("Game of Life");
        frame.setPreferredSize(WINDOW_SIZE);
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // initialize Panel for rendering Board
        panel = new Panel();
        panel.setLayout(null);
        LifeMouseListener mouseListener = new LifeMouseListener();
        panel.addMouseListener(mouseListener);
        panel.addMouseMotionListener(mouseListener);

        // FPS counter, button
        JPanel uiPanel = new JPanel();

        // fps counter
        fpsLabel = new JLabel();

        // pause button
        JButton pauseButton = new JButton("PAUSE");
        pauseButton.addActionListener(this);
        pauseButton.setActionCommand("togglePause");

        // clear button
        JButton clearButton = new JButton("CLEAR");
        clearButton.addActionListener(this);
        clearButton.setActionCommand("clearBoard");

        // add components to the JPanel
        uiPanel.add(fpsLabel);
        uiPanel.add(pauseButton);
        uiPanel.add(clearButton);

        // add the components to the Frame
        frame.add(panel);
        frame.add(uiPanel, BorderLayout.PAGE_END);

        // display window
        frame.pack();
        frame.setVisible(true);
    }

    // updates the FPS counter String
    private String createFPSCount(double fps) {
        return "FPS: " + (int) Math.round(fps);
    }

    // toggles the Pause state of the game when a button is pressed
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Action received");
        // check if it was a call to toggle the Pause state
        if (e.getActionCommand().equalsIgnoreCase("togglePause")) {
            // toggle the pause state of the game
            Life.togglePause();
        }
        else if (e.getActionCommand().equalsIgnoreCase("clearBoard")) {
            System.out.println("Clearing board...");
            // clear the board
            Board.getInstance().clear();
        }
    }

    // updates the board
    public void update(BoardState state) {
        // save the state
        this.state = state;
        // tell the panel to repaint (calls render())
        panel.repaint();
        // update fps counter
        fpsLabel.setText(createFPSCount(fps));
    }

    // renders the board, is called on every repaint()
    private void render(Graphics g) {
        // paint the border
        paintBorder(g);
        // paint the background
        paintBackground(g);
        // paint the Tiles
        if (state != null) {
            paintTiles(g);
        }
        else {
            System.out.println("Failed to render Tiles!");
        }
    }

    // paints the border
    private void paintBorder(Graphics g) {
        g.setColor(Color.BORDER.getColor());
        g.fillRect(FRAME_BOARD_MARGIN, FRAME_BOARD_MARGIN, BORDER_WIDTH, BORDER_HEIGHT);
    }

    // paints the background of the board
    private void paintBackground(Graphics g) {
        g.setColor(Color.BACKGROUND.getColor());
        g.fillRect(FRAME_BOARD_MARGIN * 2, FRAME_BOARD_MARGIN * 2, BORDER_WIDTH - 20, BORDER_HEIGHT - 20);
    }

    // paints the Tiles
    private void paintTiles(Graphics g) {
        // get the state of the board
        boolean[][] board = state.getState();

        java.awt.Color livingColor = rgb.next();

        // paint the Tiles
        java.awt.Color color;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                // get the corresponding color
                color = board[i][j] ? livingColor : Color.TILE_DEAD.getColor();
                // calculate the location
                int x = (i * (TILE_SIZE + TILE_SPACING)) + FRAME_BOARD_MARGIN * 2;
                int y = (j * (TILE_SIZE + TILE_SPACING)) + FRAME_BOARD_MARGIN * 2;
                // paint
                g.setColor(color);
                g.fillRect(x, y, TILE_SIZE, TILE_SIZE);
            }
        }
    }

    public void setFPS(double fps) {
        this.fps = fps;
    }

}
