package wenjalan.view;

public class RGBGenerator {

    private int r;
    private int g;
    private int b;
    private double increment;
    private double delta;

    public RGBGenerator() {
        r = 0;
        g = 0;
        b = 0;
        increment = 0.01f;
        delta = 0.01f;
    }

    public java.awt.Color next() {
        // reverse direction if increment reaches 1 or 0
        if (increment >= 1 || increment <= 0) {
            delta = -delta;
        }
        increment += delta;
        // System.out.println(increment);
        b = (int) (255 * Math.sin(increment));
        return new java.awt.Color(java.awt.Color.HSBtoRGB((float) increment, 1, 1));
    }

}
