package wenjalan.view;

import wenjalan.data.Board;
import wenjalan.data.Tile;
import wenjalan.util.Position;
import wenjalan.viewmodel.Life;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LifeMouseListener extends MouseAdapter {

    private static Tile lastTileUpdated;

    @Override
    public void mouseDragged(MouseEvent e) {
        // get the current Tile we're hovering over
        Position pos = getPositionOfTileAt(e.getX(), e.getY());

        // if the Position is off the board
        if (pos.x() < 0 || pos.x() > Life.BOARD_WIDTH - 1 || pos.y() < 0 || pos.y() > Life.BOARD_HEIGHT - 1) {
            // return
            return;
        }

        // get the Tile
        Tile t = Board.getInstance().getTile(pos);

        // return if this tile is the same one we updated last time
        if (t.equals(lastTileUpdated)) {
            return;
        }

        // toggle the state of the Tile
        toggleState(t);
        lastTileUpdated = t;
    }

    // changes a Tile's state at a given Position
    private static void toggleState(Tile t) {
        // toggle living state
        t.toggleLiving();
        // place it
        // TODO: Add to an update stack to prevent a CocurrentModificationException
        Board.getInstance().placeTile(t);
    }

    // returns the Position of a tile at a certain place on screen, fairly accurate
    private static Position getPositionOfTileAt(int x, int y) {
        /*
            tile coordinate = (screen position + margin) / (size of tile + tile spacing)
         */
        int tileX = (x - (int) (Window.FRAME_BOARD_MARGIN * 1.5)) / (Window.TILE_SIZE + Window.TILE_SPACING);
        int tileY = (y - (int) (Window.FRAME_BOARD_MARGIN * 1.5)) / (Window.TILE_SIZE + Window.TILE_SPACING);
        Position tilePos = new Position(tileX - 1, tileY - 1);
        // System.out.println("(" + x + ", " + y + ") -> " + tilePos);
        return tilePos;
    }

}
