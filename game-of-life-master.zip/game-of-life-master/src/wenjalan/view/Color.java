package wenjalan.view;

public enum Color {

    BACKGROUND(0, 0, 0),
    BORDER(50, 50, 50),
    TILE_ALIVE(255, 255, 0),
    TILE_DEAD(0, 0, 0);

    private java.awt.Color color;

    Color(int red, int green, int blue) {
        color = new java.awt.Color(red, green, blue);
    }

    public java.awt.Color getColor() {
        return this.color;
    }


}
