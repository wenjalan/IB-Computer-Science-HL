package wenjalan.util;

public class Position {

    // coordinates
    private int x;
    private int y;

    // constructor
    public Position(int initialX, int initialY) {
        setX(initialX);
        setY(initialY);
    }

    // setters
    public void setX(int newX) {
        this.x = newX;
    }

    public void setY(int newY) {
        this.y = newY;
    }

    // getters
    public int x() {
        return this.x;
    }

    public int y() {
        return this.y;
    }

    // toString
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

}
