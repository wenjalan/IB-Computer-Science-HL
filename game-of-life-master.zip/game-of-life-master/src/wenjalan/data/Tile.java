package wenjalan.data;

import wenjalan.util.Position;

// Represents a single Tile on the Board
public class Tile {

    // whether this tile is Alive
    private boolean isAlive;

    // the position of this Tile; is final
    private final Position position;

    // the number of living neighbors this Tile has
    private int neighborCount = 0;

    // constructor
    public Tile(Position position) {
        this.isAlive = false;
        this.position = position;
    }

    // constructor
    public Tile (Position position, boolean startsAlive) {
        this.position = position;
        this.isAlive = startsAlive;
    }

    // returns if this Tile isAlive
    public boolean isAlive() {
        return this.isAlive;
    }

    // toggles the living state of this tile
    public void toggleLiving() {
        this.isAlive = !this.isAlive;
    }

    // returns the Position of this Tile
    public Position getPosition() {
        return this.position;
    }

    // returns the number of living neighbors to this Tile
    public int getNeighborCount() {
        return this.neighborCount;
    }

    // counts living neighbors
    public void countNeighbors() {
        // get neighborCount from Board
        this.neighborCount = Board.getInstance().getNeighborCount(this);
    }



    // updates this tile based on its surrounding environment
    public void update() {
        // if neighborCount wasn't set
        if (neighborCount == -1) {
            throw new IllegalStateException("Tile called to update before checking neighbors!");
        }

        // if the tile isAlive
        if (this.isAlive) {
            // if this cell has less than 2 living adjacent cells
            if (neighborCount < 2) {
                this.isAlive = false;
            }
            // if this cell has more than 3 living neighbors
            else if (neighborCount > 3) {
                this.isAlive = false;
            }
            // if this cell has two or three neighbors
            else if (neighborCount == 2 || neighborCount == 3) {
                this.isAlive = true;
            }
        }
        // if it isn't
        else {
            // if there are 3 living tiles next to this one
            if (neighborCount == 3) {
                // revive this cell
                this.isAlive = true;
            }
        }

    }

}
