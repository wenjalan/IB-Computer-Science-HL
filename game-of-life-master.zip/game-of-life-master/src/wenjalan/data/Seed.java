package wenjalan.data;

import wenjalan.util.Position;

// Represents a Seed, a non-perishable Tile
public class Seed extends Tile {

    // constructor
    public Seed(Position position) {
        super(position);
    }

    @Override
    public boolean isAlive() {
        return true;
    }

    @Override
    public void update() {
        return;
    }

}
