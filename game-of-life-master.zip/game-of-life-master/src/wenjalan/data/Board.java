package wenjalan.data;

import wenjalan.util.Position;
import wenjalan.viewmodel.BoardState;
import wenjalan.viewmodel.Life;

import java.util.ConcurrentModificationException;
import java.util.Stack;

import static wenjalan.viewmodel.Life.BOARD_HEIGHT;
import static wenjalan.viewmodel.Life.BOARD_WIDTH;

// a singleton instance of the Board, which holds the array of Tile(s)
public class Board {

    // the singleton instance
    private static Board INSTANCE = new Board();

    // array of Tiles that acts as the board
    private Tile[][] board;

    // a Stack of Tiles that is going to be added to the Board next update
    private Stack<Tile> placeStack;

    // returns the instance of Board
    public static Board getInstance() {
        // check if the Board is null
        if (INSTANCE == null) {
            throw new IllegalStateException("Board is null!");
        }
        // return the instance
        return INSTANCE;
    }

    // constructor
    private Board() {
        // initialize
        init();
    }

    // initialization
    private void init() {
        // initialize board
        this.board = new Tile[BOARD_WIDTH][BOARD_HEIGHT];

        // initialize place stack
        this.placeStack = new Stack<>();

        // fill board with Tiles
        for (int i = 0; i < BOARD_WIDTH; i++) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                // create a new instance of Tile at the current position
                Tile t = new Tile(new Position(i, j));
                this.board[i][j] = t;
            }
        }
    }

    // updates the board
    public BoardState update() {
        // update the tiles
        // TODO: Only update tiles with live neighbors
        // tiles to update
        // Stack<Tile> tilesToUpdate = new Stack<>();
        // place down the tiles in placeStack
        try {
            for (Tile t : placeStack) {
                setTile(t);
                // tilesToUpdate.add(t);
            }
        } catch (ConcurrentModificationException e) {
            System.err.println("Updating too many tiles at once!");
            // e.printStackTrace();
        }

        for (Tile[] ta : board) {
            // make each Tile count its neighbors
            for (Tile t : ta) {
                t.countNeighbors();
                // if the Tile has any living neighbors
                if (t.getNeighborCount() > 0) {
                    // add it to the update stack
                    // tilesToUpdate.add(t);
                }
            }
        }
        // update all the Tiles in the update stack
        if (!Life.isPaused()) {
//            for (Tile t : tilesToUpdate) {
//                t.update();
//            }
            for (Tile[] tiles : board) {
                for (Tile t : tiles) {
                    t.update();
                }
            }
        }


        // return the state of the board
        return new BoardState(board);
    }

    // clears the board (sets all Tiles to dead)
    public void clear() {
        for (Tile[] tiles : board) {
            for (Tile t : tiles) {
                if (!t.isAlive()) {
                    t.toggleLiving();
                }
            }
        }
    }

    // returns a Tile at a given Position
    public Tile getTile(Position position) {
        return this.board[position.x()][position.y()];
    }

    // adds a Tile to the placeStack, for placement upon next update
    public void placeTile(Tile tile) {
        // get the position
        // int x = tile.getPosition().x();
        // int y = tile.getPosition().y();

        // set the Tile
        // board[x][y] = tile;

        // add the Tile to the queue
        placeStack.add(tile);
    }

    // sets a Tile at a certain position
    private void setTile(Tile t) {
        board[t.getPosition().x()][ t.getPosition().y()] = t;
    }

    // returns the number of living, adjacent Tile(s) to a given Tile
    public int getNeighborCount(Tile tile) {
        // get the position of this Tile
        int xPos = tile.getPosition().x();
        int yPos = tile.getPosition().y();

        // find out if this Tile is on a border
        boolean topBorder = yPos <= 0;
        boolean rightBorder = xPos >= BOARD_WIDTH - 1;
        boolean bottomBorder = yPos >= BOARD_HEIGHT - 1;
        boolean leftBorder = xPos <= 0;

        // if the Tile is in a corner
        boolean topLeft = topBorder && leftBorder;
        boolean topRight = topBorder && rightBorder;
        boolean bottomRight = bottomBorder && rightBorder;
        boolean bottomLeft = bottomBorder && leftBorder;

        // keep track of all the neighbor tiles, alive or not
        Stack<Tile> neighbors = new Stack<>();

        // get the neighbor Tiles
        // TODO: Change from getTile(new Position(relativePosition)) to something cleaner
        try {
            // if this Tile is in a corner
            if (topLeft || topRight || bottomRight || bottomLeft) {
                if (topLeft) {
                    // right
                    neighbors.add(getTile(new Position(xPos + 1, yPos)));
                    // bottom-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos + 1)));
                    // bottom
                    neighbors.add(getTile(new Position(xPos, yPos + 1)));
                }
                else if (topRight) {
                    // left
                    neighbors.add(getTile(new Position(xPos - 1, yPos)));
                    // bottom left
                    neighbors.add(getTile(new Position(xPos - 1, yPos + 1)));
                    // bottom
                    neighbors.add(getTile(new Position(xPos, yPos + 1)));
                }
                else if (bottomRight) {
                    // top left
                    neighbors.add(getTile(new Position(xPos - 1, yPos - 1)));
                    // top
                    neighbors.add(getTile(new Position(xPos, yPos - 1)));
                    // left
                    neighbors.add(getTile(new Position(xPos - 1, yPos)));
                }
                else if (bottomLeft) {
                    // top
                    neighbors.add(getTile(new Position(xPos, yPos - 1)));
                    // top-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos - 1)));
                    // right
                    neighbors.add(getTile(new Position(xPos + 1, yPos)));
                }
                else {
                    throw new IllegalStateException("This should be impossible.");
                }
            }
            // if this Tile is on a border
            else if (topBorder || rightBorder || bottomBorder || leftBorder) {
                if (topBorder) {
                    // left
                    neighbors.add(getTile(new Position(xPos - 1, yPos)));
                    // right
                    neighbors.add(getTile(new Position(xPos + 1, yPos)));
                    // bottom left
                    neighbors.add(getTile(new Position(xPos - 1, yPos + 1)));
                    // bottom
                    neighbors.add(getTile(new Position(xPos, yPos + 1)));
                    // bottom-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos + 1)));
                }
                else if (rightBorder) {
                    // top left
                    neighbors.add(getTile(new Position(xPos - 1, yPos - 1)));
                    // top
                    neighbors.add(getTile(new Position(xPos, yPos - 1)));
                    // left
                    neighbors.add(getTile(new Position(xPos - 1, yPos)));
                    // bottom left
                    neighbors.add(getTile(new Position(xPos - 1, yPos + 1)));
                    // bottom
                    neighbors.add(getTile(new Position(xPos, yPos + 1)));
                }
                else if (bottomBorder) {
                    // top left
                    neighbors.add(getTile(new Position(xPos - 1, yPos - 1)));
                    // top
                    neighbors.add(getTile(new Position(xPos, yPos - 1)));
                    // top-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos - 1)));
                    // left
                    neighbors.add(getTile(new Position(xPos - 1, yPos)));
                    // right
                    neighbors.add(getTile(new Position(xPos + 1, yPos)));
                }
                else if (leftBorder) {
                    // top
                    neighbors.add(getTile(new Position(xPos, yPos - 1)));
                    // top-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos - 1)));
                    // right
                    neighbors.add(getTile(new Position(xPos + 1, yPos)));
                    // bottom
                    neighbors.add(getTile(new Position(xPos, yPos + 1)));
                    // bottom-right
                    neighbors.add(getTile(new Position(xPos + 1, yPos + 1)));
                }
                else {
                    throw new IllegalStateException("This should be impossible.");
                }
            }
            // if the Tile is neither in a corner or on a border
            else {
                // check the surrounding 8 Tiles
                // top left
                neighbors.add(getTile(new Position(xPos - 1, yPos - 1)));
                // top
                neighbors.add(getTile(new Position(xPos, yPos - 1)));
                // top-right
                neighbors.add(getTile(new Position(xPos + 1, yPos - 1)));
                // left
                neighbors.add(getTile(new Position(xPos - 1, yPos)));
                // right
                neighbors.add(getTile(new Position(xPos + 1, yPos)));
                // bottom left
                neighbors.add(getTile(new Position(xPos - 1, yPos + 1)));
                // bottom
                neighbors.add(getTile(new Position(xPos, yPos + 1)));
                // bottom-right
                neighbors.add(getTile(new Position(xPos + 1, yPos + 1)));
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Tried to access a Tile beyond the borders of the Board!");
            System.err.printf("Target Tile Position: (%d,%d)%n", xPos, yPos);
            e.printStackTrace();
            System.exit(1);
        }

        // count how many of the neighbors are alive
        int count = 0;
        for (Tile t : neighbors) {
            if (t.isAlive()) {
                count++;
            }
        }

        // return the count
        return count;
    }

    // prints the Board to the console, for debugging
    /* public void print() {
        // print each Tile to the console
        for (Tile[] ta : board) {
            for (Tile t : ta) {
                // if it's alive, print an 'O'
                if (t.isAlive()) {
                    System.out.print("O");
                }
                else {
                    System.out.print("-");
                }
            }
            System.out.println();
        }
    } */

}
