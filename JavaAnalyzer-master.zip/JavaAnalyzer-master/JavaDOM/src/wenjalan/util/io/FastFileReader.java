package wenjalan.util.io;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.NoSuchElementException;

// reads files using the Java NIO API
public class FastFileReader {

    // the default buffer size
    private static final int DEFAULT_BUFFER_SIZE = 1024;

    // the file to read from
    private RandomAccessFile file;

    // the channel to read from
    private FileChannel channel;

    // the buffer to read into
    private ByteBuffer buffer;

    // a giant String to store the data
    private String[] tokens;

    // the index of the next token to return
    private int nextIndex;

    // main constructor
    public FastFileReader(RandomAccessFile file, int bufferSize) {
        this.file = file;
        this.channel = file.getChannel();
        this.buffer = ByteBuffer.allocate(bufferSize);
        this.nextIndex = 0;
        read();
    }

    public FastFileReader(RandomAccessFile file) {
        this(file, DEFAULT_BUFFER_SIZE);
    }

    // reads the file into the ArrayList data
    private void read() {
        try {
            // read from the File into the StringBuffer
            StringBuffer stringBuffer = new StringBuffer();
            int bytesRead = channel.read(buffer);
            while (bytesRead != -1) {
                buffer.flip();
                while (buffer.hasRemaining()) {
                    // data.add(buffer.get());
                    byte b = buffer.get();
                    stringBuffer.append((char) b);
                }
                buffer.clear();
                bytesRead = channel.read(buffer);
            }
            channel.close();

            // split the dataString into tokens
            String str = stringBuffer.toString();
            tokens = str.split("\\s+");
        } catch (IOException e) {
            System.err.println("Failed to read file " + file);
            e.printStackTrace();
        }
    }

    // returns the next String token of the data
    public String next() {
        if (nextIndex == tokens.length) {
            throw new NoSuchElementException("Reached end of file");
        }
        String token = tokens[nextIndex];
        nextIndex++;
        return token;
    }

    // returns whether or not there is a next token
    public boolean hasNext() {
        if (nextIndex >= tokens.length) {
            return false;
        }
        else {
            return true;
        }
    }

    // returns a copy of the String[] backing this FastFileReader
    public String[] array() {
        return Arrays.copyOf(tokens, tokens.length);
    }

}