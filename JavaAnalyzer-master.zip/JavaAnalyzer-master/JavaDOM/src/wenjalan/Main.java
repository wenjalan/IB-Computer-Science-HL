package wenjalan;

import wenjalan.model.*;

import java.io.FileNotFoundException;
import java.io.RandomAccessFile;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        // RandomAccessFile f = new RandomAccessFile(args[0], "r");
        // JavaDOM dom = new JavaDOM(f);

        ClassModel class_main = new ClassModel(MemberModel.PRIVACY_LEVEL.PUBLIC, "Main");

        FieldModel field = new FieldModel(MemberModel.PRIVACY_LEVEL.PUBLIC, "String", "name", "Alan Wen");
        class_main.addChild(field);

        ConstructorModel constructor = new ConstructorModel(class_main, MemberModel.PRIVACY_LEVEL.PUBLIC, new ParameterModel());
        class_main.addChild(constructor);

        MethodModel method = new MethodModel(MemberModel.PRIVACY_LEVEL.PUBLIC, "void", "method", new ParameterModel());
        class_main.addChild(method);

        ClassModel subclass = new ClassModel(MemberModel.PRIVACY_LEVEL.PUBLIC, "Subclass");
        class_main.addChild(subclass);

        System.out.println(class_main);
    }

}
