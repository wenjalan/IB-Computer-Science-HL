package wenjalan.model;

import java.util.List;

// represents a MemberModel that can have ChildModels (class, method, etc.)
public interface ParentModel {

    // retrieve list of children
    List<ChildModel> getChildren();

    // add a child to this ParentModel
    boolean addChild(ChildModel child);

    // add a List of children to this ParentModel
    boolean addChildren(List<ChildModel> children);

    // removes a child from this ParentModel
    boolean removeChild(ChildModel child);

    // removes a List of children from this ParentModel
    boolean removeChildren(List<ChildModel> children);

}
