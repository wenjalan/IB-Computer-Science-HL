package wenjalan.model;

import javafx.scene.Parent;

// represents a member of a class inside an ObjectModel
public abstract class MemberModel {

    // enum for privacy levels
    public enum PRIVACY_LEVEL {
        LOCAL,
        PRIVATE,
        PROTECTED,
        PACKAGE,
        PUBLIC;
    }

    // the identifier of this member
    final protected String identifier;

    // the privacy level of this member
    final protected PRIVACY_LEVEL privacyLevel;

    // constructor
    protected MemberModel(PRIVACY_LEVEL privacyLevel, String identifier) {
        this.identifier = identifier;
        this.privacyLevel = privacyLevel;
    }

    // accessors //
    public String getIdentifier() {
        return identifier;
    }

    public PRIVACY_LEVEL getPrivacyLevel() {
        return privacyLevel;
    }

    // utils //
    // returns the number of ancestors a child has
    public static int getAncestorCount(ChildModel child) {
        ParentModel parent = child.getParent();
        if (!(parent instanceof ChildModel))
            return 1;
        else
            return 1 + getAncestorCount((ChildModel) parent);
    }

}