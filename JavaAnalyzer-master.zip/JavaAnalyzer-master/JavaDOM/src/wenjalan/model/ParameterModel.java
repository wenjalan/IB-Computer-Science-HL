package wenjalan.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;

// represents the parameters of a MethodModel
public class ParameterModel {

    // the parameters
    private ArrayList<Parameter> parametersList;

    // constructor
    public ParameterModel() {
        parametersList = new ArrayList<>();
    }

    // add a parameter to the list
    public ParameterModel add(String type, String identifier) {
        parametersList.add(new Parameter(type, identifier));
        return this;
    }

    // returns the parameters in the format <type> <identifier> separated by commas
    @Override
    public String toString() {
        if (parametersList.isEmpty()) {
            return "";
        }
        else {
            String ret = "";
            for (Parameter p : parametersList) {
                ret += p.type + " " + p.identifier + ", ";
            }
            return ret.substring(0, ret.length() - 2);
        }
    }

    // represents a Parameter inside the ParameterModel
    protected class Parameter {
        String type;
        String identifier;

        public Parameter(String type, String identifier) {
            this.type = identifier;
            this.identifier = identifier;
        }

    }

}
