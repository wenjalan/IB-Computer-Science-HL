package wenjalan.model;

import java.util.ArrayList;
import java.util.List;

// represents a Method inside a Class
public class MethodModel extends MemberModel implements ParentModel, ChildModel {

    protected ParentModel parent;
    protected ArrayList<ChildModel> children;
    protected String returnType;
    protected ParameterModel parameters;

    // constructor
    public MethodModel(PRIVACY_LEVEL privacyLevel, String returnType, String identifier, ParameterModel parameters) {
        super(privacyLevel, identifier);
        this.returnType = returnType;
        this.parameters = parameters;
    }

    // accessors //
    // returns the return type of this method as a String
    public String getReturnType() {
        return this.returnType;
    }

    // returns the ParameterModel of this MethodModel
    public ParameterModel getParameters() {
        return this.parameters;
    }

    // ChildModel Overrides //
    @Override
    public void setParent(ParentModel parent) {
        this.parent = parent;
    }

    @Override
    public ParentModel getParent() {
        return this.parent;
    }

    // ParentModel Overrides //
    @Override
    public List<ChildModel> getChildren() {
        return this.children;
    }

    @Override
    public boolean addChild(ChildModel child) {
        boolean result = this.children.add(child);
        if (result) child.setParent(this);
        return result;
    }

    @Override
    public boolean addChildren(List<ChildModel> children) {
        boolean result = this.children.addAll(children);
        if (result) for (ChildModel c : children) c.setParent(this);
        return result;
    }

    @Override
    public boolean removeChild(ChildModel child) {
        boolean result = this.children.remove(child);
        if (result) child.setParent(null);
        return result;
    }

    @Override
    public boolean removeChildren(List<ChildModel> children) {
        boolean result = this.children.removeAll(children);
        if (result) for (ChildModel c : children) c.setParent(null);
        return result;
    }

    // toString //
    @Override
    public String toString() {
        return privacyLevel.toString().toLowerCase() + " " + returnType + " " + identifier + "(" + parameters + ")";
    }

}
