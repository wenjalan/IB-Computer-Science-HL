package wenjalan.model;

public class VariableModel extends FieldModel {

    // constructor
    public VariableModel(String type, String identifier, String data) {
        super(PRIVACY_LEVEL.LOCAL, type, identifier, data);
    }

    // toString
    @Override
    public String toString() {
        return type + " " + identifier + " = " + data;
    }

}
