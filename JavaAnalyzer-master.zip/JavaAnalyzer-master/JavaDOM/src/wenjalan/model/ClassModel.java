package wenjalan.model;

import java.util.ArrayList;
import java.util.List;

public class ClassModel extends MemberModel implements ParentModel, ChildModel {

    // the parent of this ClassModel
    protected ParentModel parent = null;

    // the list of members this Class contains
    protected ArrayList<ChildModel> children = null;

    // constructor
    public ClassModel(MemberModel.PRIVACY_LEVEL privacyLevel, String identifier) {
        super(privacyLevel, identifier);
        init();
    }

    // builder
    public static class Builder {

        // the properties of a Class
        private PRIVACY_LEVEL privacy = PRIVACY_LEVEL.PACKAGE;
        private final String identifier;

        // constructor
        public Builder(String identifier) {
            this.identifier = identifier;
        }

        // privacy
        public Builder privacy(PRIVACY_LEVEL privacyLevel) {
            this.privacy = privacyLevel;
            return this;
        }

        // build
        public ClassModel build() {
            return new ClassModel(privacy, identifier);
        }

    }

    // initialization
    protected void init() {
        this.children = new ArrayList<>();
    }

    // ParentModel Overrides //
    @Override
    public List<ChildModel> getChildren() {
        return this.children;
    }

    @Override
    public boolean addChild(ChildModel child) {
        boolean result = this.children.add(child);
        if (result) child.setParent(this);
        return result;
    }

    @Override
    public boolean addChildren(List<ChildModel> children) {
        boolean result = this.children.addAll(children);
        if (result) for (ChildModel c : children) c.setParent(this);
        return result;
    }

    @Override
    public boolean removeChild(ChildModel child) {
        boolean result = this.children.remove(child);
        if (result) child.setParent(null);
        return result;
    }

    @Override
    public boolean removeChildren(List<ChildModel> children) {
        boolean result = this.children.removeAll(children);
        if (result) for (ChildModel c : children) c.setParent(null);
        return result;
    }

    // ChildModel Overrides //
    @Override
    public void setParent(ParentModel parent) {
        this.parent = parent;
    }

    @Override
    public ParentModel getParent() {
        return this.parent;
    }

    // toString
    @Override
    public String toString() {
        // get the number of indents we should indent this class by
        int indents = getAncestorCount(this);
        String ret = getPrivacyLevel().toString().toLowerCase() + " class " + getIdentifier();
        for (ChildModel child : getChildren()) {
            ret += "\n";
            for (int i = 0; i < indents; i++) {
                ret += "\t";
            }
            ret += child;
        }
        return ret;
    }

}
