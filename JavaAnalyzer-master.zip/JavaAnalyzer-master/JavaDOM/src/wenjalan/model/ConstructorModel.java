package wenjalan.model;

public class ConstructorModel extends MethodModel implements ParentModel, ChildModel {

    protected ClassModel parentClass;

    public ConstructorModel(ClassModel classModel, PRIVACY_LEVEL privacyLevel, ParameterModel parameters) {
        super(privacyLevel, classModel.getIdentifier(), classModel.getIdentifier(), parameters);
        this.parentClass = classModel;
    }

    @Override
    public String getReturnType() {
        throw new UnsupportedOperationException("Constructors don't have a return type");
    }

    @Override
    public String toString() {
        return privacyLevel.toString().toLowerCase() + " " + identifier + "(" + parameters + ")";
    }

}
