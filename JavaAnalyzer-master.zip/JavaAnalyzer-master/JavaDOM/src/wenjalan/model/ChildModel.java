package wenjalan.model;

// represents a MemberModel that can be the child of a ParentModel
public interface ChildModel {

    // sets the parent of this ChildModel
    void setParent(ParentModel parent);

    // returns the ParentModel of this ChildModel
    ParentModel getParent();

}
