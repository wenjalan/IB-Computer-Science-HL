package wenjalan.model;

public class FieldModel extends MemberModel implements ChildModel {

    // the parent of this FieldModel
    protected ParentModel parent = null;

    // the type of the data this FieldModel represents
    protected String type;

    // the data this FieldModel represents
    protected String data;

    // constructor
    public FieldModel(PRIVACY_LEVEL privacyLevel, String type, String identifier, String data) {
        super(privacyLevel, identifier);
        this.type = type;
        this.data = data;
    }

    // accessors
    // returns the type of data this FieldModel represents
    public String getType() {
        return type;
    }

    // returns the data represented by this FieldModel
    public String getData() {
        return data;
    }

    // ChildModel Overrides //
    // sets the ParentModel of this FieldModel
    @Override
    public void setParent(ParentModel parent) {
        this.parent = parent;
    }

    // returns the ParentModel of this FieldModel
    @Override
    public ParentModel getParent() {
        return this.parent;
    }

    // toString
    @Override
    public String toString() {
        return privacyLevel.toString().toLowerCase() + " " + type + " " + identifier + " = " + data;
    }
}
