package wenjalan;

import wenjalan.util.io.FastFileReader;

import java.io.RandomAccessFile;
import java.util.Stack;

public class JavaDOM {

    // file reader, from wenjalan util library
    private FastFileReader fileReader;

    // constructor
    public JavaDOM(RandomAccessFile sourceFile) {
        fileReader = new FastFileReader(sourceFile);
    }

    // starts verification
    public boolean verify() {
        // check verifyBrackets
        if (!verifyBrackets()) {
            return false;
        }

        // if no errors were found, return true
        return true;
    }

    // verifies that the source file has no loose brackets {}, [], ()
    // returns false if an error was found, returns true if none were found
    private boolean verifyBrackets() {
        // the entire file in String form
        String[] tokens = fileReader.array();
        // the stack of Brackets
        Stack<Character> bracketStack = new Stack<>();

        // iterate through the tokens
        for (String t : tokens) {
            // get the chars
            char[] chars = t.toCharArray();
            for (char c : chars) {
                // if this char is an opening bracket, add it to the stack
                if (c == '{' || c == '(' || c == '[') {
                    bracketStack.push(c);
                }
                // if this char is a closing bracket, pop the last char off the stack and compare
                else if (c == '}' || c == ')' || c == ']') {
                    // if the stack is empty, return false
                    // means there's more closing brackets than open ones
                    if (bracketStack.isEmpty()) {
                        return false;
                    }

                    // get the corresponding bracket
                    char otherBracket = getBracket(c);

                    // compare the two brackets
                    // if the bracket at the top of the stack and this bracket don't match, return false
                    char lastBracket = bracketStack.pop();
                    if (otherBracket != lastBracket) {
                        return false;
                    }
                }
            }
        }

        // if there are any unclosed brackets, return false
        if (!bracketStack.isEmpty()) {
            return false;
        }

        // return true if no errors were found
        return true;
    }

    // creates a DOM

    // returns the appropriate partner bracket given a bracket
    private static char getBracket(char c) {
        switch (c) {
            case '(':
                return ')';
            case ')':
                return '(';
            case '[':
                return ']';
            case ']':
                return '[';
            case '}':
                return '{';
            case '{':
                return '}';
            case '<':
                return '>';
            case '>':
                return '<';
            default:
                throw new IllegalArgumentException("Unsupported bracket: " + c);
        }
    }

}
