package wenjalan;

import java.io.IOException;

public class Huffman {

	public static final String COMPRESSED_FILE_EXTENSION = ".huf";
	public static final String MAP_FILE_EXTENSION = ".hmap";

    public static void main(String[] args) throws IOException {
	    if (args[0].equals("compress")) {
	        new Compressor(args[1]).compress();

        }
	    else if (args[0].equals("decompress")){
	        new Decompressor(args[1], args[2]).decompress();
        }
	    else {
	        throw new IllegalArgumentException("huffman <compress/decompress> <filepath>");
        }
    }
}
