package wenjalan;

import wenjalan.utils.ArrayUtils;
import wenjalan.utils.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class HuffmanTree {

    protected class Node {

        char c; // the character to represent
        long occurances; // the number of times this character occurs in the file

        Node left;
        Node right;

        Node(long occurances) {
            this.occurances = occurances;
        }

        Node(char c, long occurances) {
            this.c = c;
            this.occurances = occurances;
        }

        @Override
        public String toString() {
            return (c + "," + occurances);
        }

        public long getOccurances() {
            return occurances;
        }

        public char getChar() {
            return c;
        }

    }

    // root node of the tree
    protected Node root;

    // the char-to-bits map
    protected Map<Character, String> charMap;

    // the bit-to-char map
    protected Map<String, Character> bitMap;

    public HuffmanTree(char[] chars) {
        // create the tree
        root = generateTree(chars);

        // generate the maps
        charMap = generateCharMap(root);
        bitMap = CollectionUtils.reverseMap(charMap);
    }

    protected Node generateTree(char[] chars) {
        // generate frequency map
        Character[] a = ArrayUtils.toBoxedArray(chars);
        Map<Character, Long> freq = Stream.of(a).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        // generate a Node for each character
        List<Node> nodes = freq.keySet().stream().map(c -> new Node(c, freq.get(c))).collect(Collectors.toList());

        // add all to a priority queue
        PriorityQueue<Node> queue = new PriorityQueue<>(Comparator.comparingLong(Node::getOccurances));
        queue.addAll(nodes);

        /*
         * 1. Pop the next 2 nodes off the queue
         * 2. Create a new parent node
         * 3. Set the parent node's occurences to the sum of the child nodes
         * 4. Set the left child node to the node with less occurences
         * 5. Set the right node
         * 6. Add the parent node back into the queue
         */
        while (queue.size() > 1) {
            System.out.println(queue);
            Node n1 = queue.remove();
            Node n2 = queue.remove();
            Node parent = new Node(n1.occurances + n2.occurances);
            parent.left = n1;
            parent.right = n2;
            queue.add(parent);
        }

        System.out.println(queue);

        // return the last node in the queue
        return queue.remove();
    }

    protected Map<Character, String> generateCharMap(Node root) {
        Map<Character, String> map = new HashMap<>();
        generateCharMap(root, "", map);
        return map;
    }

    void generateCharMap(Node node, String bits, Map<Character, String> map) {
        if (node.getChar() != '\0') {
            map.put(node.getChar(), bits);
            System.out.println(bits + ":" + node.getChar());
        }
        else {
            generateCharMap(node.left, bits + "0", map);
            generateCharMap(node.right, bits + "1", map);
        }
    }

    // returns the char to bit map
    public Map<Character, String> getCharMap() {
        return charMap;
    }

    public Map<String, Character> getBitMap() {
        return bitMap;
    }
}
