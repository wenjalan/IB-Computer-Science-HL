package wenjalan;

import com.google.gson.Gson;
import io.BitOutputStream;
import wenjalan.io.FastReader;
import wenjalan.io.FastWriter;
import wenjalan.utils.StringUtils;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.util.*;

public class Compressor {

    // the file to read from
    protected File file;

    // constructor
    public Compressor(String filepath) {
        file = new File(filepath);
    }

    // starts the compression
    public void compress() throws IOException {
        // read the file
        byte[] bytes = Files.readAllBytes(file.toPath());

        // convert to char[]
        char[] chars = new char[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            chars[i] = (char) bytes[i];
        }

        // generate the HuffmanTree
        HuffmanTree huffmanTree = new HuffmanTree(chars);

        // generate compressed file using the tree
        writeCompressedFile(file, huffmanTree);
    }

    // writes the file
    protected void writeCompressedFile(File sourceFile, HuffmanTree tree) throws IOException {
        // initialize reader and writer
        FileChannel inChannel = new RandomAccessFile(sourceFile, "r").getChannel();
        FastReader reader = new FastReader(inChannel);

        // get the name of the output file
        String outFileName = StringUtils.truncateAt(sourceFile.getName(), '.') + Huffman.COMPRESSED_FILE_EXTENSION;

        // FileChannel outChannel = new RandomAccessFile(outFileName, "rw").getChannel();
        // FastWriter writer = new FastWriter(outChannel, 500);
        BitOutputStream bos = new BitOutputStream(new FileOutputStream(outFileName), true);

        // for every char in the in file, write the corresponding bit string to the out file
        Map<Character, String> charMap = tree.getCharMap();
        while (reader.hasNext()) {
            char c = (char) reader.next();
            if (c == '\0') {
                break;
            }
            String bits = charMap.get(c);
            bos.writeBits(bits);
        }

        // write the tree to a .hmap
        String mapFileName = StringUtils.truncateAt(sourceFile.getName(), '.') + Huffman.MAP_FILE_EXTENSION;
        FastWriter writer = new FastWriter(new RandomAccessFile(mapFileName, "rw").getChannel());
        Map<String, Character> bitMap = tree.getBitMap();
        String mapGson = new Gson().toJson(bitMap);
        writer.write(mapGson);
        writer.close();

        // close everything
        bos.close();
        reader.close();
    }

}
