package wenjalan;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.BitInputStream;
import wenjalan.io.FastWriter;
import wenjalan.utils.ArrayUtils;
import wenjalan.utils.StringUtils;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class Decompressor {

    // the file to read from
    protected File file;

    // the map of Bits to Chars
    Map<String, Character> bitMap;

    // map should be of type String, Character
    @SuppressWarnings("unchecked")
    public Decompressor(String compressFilePath, String mapFilePath) throws FileNotFoundException {
        file = new File(compressFilePath);
        bitMap = new Gson().fromJson(new FileReader(new File(mapFilePath)), new TypeToken<Map<String, Character>>(){}.getType());

    }

    public void decompress() throws IOException {
        // read the file
        BitInputStream bitInputStream = new BitInputStream(new FileInputStream(file), true);
        ArrayList<Integer> bits = new ArrayList<>();
        while (bitInputStream.hasNextBit()) {
            bits.add(bitInputStream.readBit());
        }

        // convert the file to a char[]
        //List<Character> decompressed =
        List<Character> decompressed = map(bits);

        char[] chars = new char[decompressed.size()];
        for (int i = 0; i < decompressed.size(); i++) {
            chars[i] = decompressed.get(i);
        }

        // write the chars to the file
        write(chars);
    }

    // converts a list of bits (as integers) to their respective representations as bytes
    protected List<Character> map(List<Integer> bits) {
        // the list of chars retrieved from the bits
        ArrayList<Character> chars = new ArrayList<>();

        // the bits read from the list of bits
        String byteString = "";

        // an iterator to read through the bits
        Iterator<Integer> iterator = bits.iterator();
        while (iterator.hasNext()) {
            // add the next bit to the byteString
            byteString += iterator.next();

            // if this pattern of bits is in the map
            if (bitMap.keySet().contains(byteString)) {
                // add the corresponding char to the byte array

                /*******************************************************************************************************
                 *  -- THIS LINE BREAKS THE ENTIRE PROGRAM AND I CAN'T FIGURE OUT WHY --
                 *
                 * - bitMap:      A <String, Character> map. Given a bit string, returns the corresponding character.
                 * - byteString:  The bit representation of a character, read bit-by-bit from test.huf
                 * - c:           The character to retrieve from the map (throws a cast error?)
                 *
                 * Notes:
                 * - For some reason, println is able to print out value of bitMap.get(byteString) no problem
                 */
//                System.out.print(byteString + ":");
//                System.out.println(bitMap.get(byteString).getClass());
//                System.out.println((int) bitMap.get(byteString));
                Character c = bitMap.get(byteString);





                // workaround: add the result of bitMap.get() to an empty String at get charAt(0)
                // Character c = ("" + bitMap.get(byteString)).charAt(0);
                // add the character to the list
                 chars.add(c);
                // clear the byteString
                byteString = "";
            }
        }
        // return the list of chars
        return chars;
    }

    // writes the decompressed file
    protected void write(char[] data) throws IOException {
        String fileName = StringUtils.truncateAt(file.getName(), '.') + ".txt";
        FastWriter fastWriter = new FastWriter(new RandomAccessFile(fileName, "rw").getChannel());
        for (char datum : data) {
            // System.out.println(datum);
            fastWriter.write(datum);
        }
        fastWriter.close();
    }

}
